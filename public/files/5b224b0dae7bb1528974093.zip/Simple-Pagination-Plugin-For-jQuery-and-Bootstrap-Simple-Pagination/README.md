simple-pagination
===============================

Bootstrap Pagination

[See the demo](http://shkolovy.github.io/simple-pagination/test.html)

![ScreenShot](https://raw.github.com/artemdude/simple-pagination/master/screenshots/pagination.png)
